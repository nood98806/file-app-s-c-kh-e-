// --- Data State ---
let state = {
    bmr: 1600,
    waterCurrent: 0,
    waterTarget: 2000,
    caloriesCurrent: 0,
    caloriesBurned: 0,
    waterHistory: [],
    foodHistory: [],
    schedule: {}
};

// --- Food Database (Vietnam) ---
const foodDB = [
    { name: "Phở bò", cal: 214 }, // per 100g or 1 bowl ~ 400-500. Let's make it per 100g or unit
    { name: "Phở gà", cal: 200 },
    { name: "Cơm tấm sườn bì chả", cal: 600 },
    { name: "Bánh mì thịt", cal: 350 },
    { name: "Bún chả Hà Nội", cal: 450 },
    { name: "Trà sữa trân châu", cal: 350 },
    { name: "Cà phê sữa đá", cal: 150 },
    { name: "Táo", cal: 52 },
    { name: "Chuối", cal: 89 },
    { name: "Cơm trắng (1 chén)", cal: 130 },
    { name: "Thịt lợn luộc", cal: 242 },
    { name: "Thịt gà luộc", cal: 165 },
    { name: "Rau muống xào tỏi", cal: 112 },
    { name: "Bò bít tết", cal: 271 },
    { name: "Mì tôm (1 gói)", cal: 350 },
    { name: "Bánh xèo", cal: 400 },
    { name: "Bún bò Huế", cal: 479 },
    { name: "Bánh cuốn", cal: 300 }
];

let selectedFood = null;

// --- Init & Navigation ---
document.addEventListener('DOMContentLoaded', () => {
    updateDate();
    initFoodSearch();
    updateUI();
});

function updateDate() {
    const today = new Date();
    document.getElementById('current-date').textContent = today.toLocaleDateString('vi-VN');
}

function navigate(screenId, navItem = null) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(screenId).classList.add('active');
    
    if (navItem) {
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        navItem.classList.add('active');
    }
}

// --- 1. Profile / BMI ---
function calculateBMI() {
    const w = parseFloat(document.getElementById('profile-weight').value);
    const h = parseFloat(document.getElementById('profile-height').value) / 100;
    const a = parseInt(document.getElementById('profile-age').value);
    const g = document.getElementById('profile-gender').value;

    if (!w || !h || !a) return alert("Vui lòng nhập đủ thông tin!");

    // BMI
    const bmi = (w / (h * h)).toFixed(1);
    document.getElementById('bmi-value').textContent = bmi;

    let status = "Bình thường";
    if (bmi < 18.5) status = "Gầy";
    else if (bmi >= 25) status = "Thừa cân";
    document.getElementById('bmi-status').textContent = status;

    // BMR (Mifflin-St Jeor)
    let bmr = (10 * w) + (6.25 * (h * 100)) - (5 * a);
    bmr += (g === 'male') ? 5 : -161;
    bmr = Math.round(bmr * 1.2); // x1.2 cho vận động nhẹ

    state.bmr = bmr;
    document.getElementById('bmr-value').textContent = bmr;
    document.getElementById('bmi-result').classList.remove('hidden');

    updateUI();
    alert("Đã cập nhật hồ sơ!");
}

// --- 2. Water Tracking ---
function addWater(amount) {
    state.waterCurrent += amount;
    const now = new Date().toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'});
    state.waterHistory.unshift({ time: now, text: `Uống ${amount}ml nước` });
    updateUI();
}

function addCustomWater() {
    const val = parseInt(document.getElementById('water-custom-val').value);
    if (val && val > 0) {
        addWater(val);
        document.getElementById('water-custom-val').value = '';
    }
}

function resetWater() {
    state.waterCurrent = 0;
    state.waterHistory = [];
    updateUI();
}

// --- 3. Sleep Management ---
function calculateSleep() {
    const start = document.getElementById('sleep-start').value;
    const end = document.getElementById('sleep-end').value;
    
    if(!start || !end) return;

    let dStart = new Date(`2000-01-01T${start}:00`);
    let dEnd = new Date(`2000-01-01T${end}:00`);
    
    if (dEnd < dStart) {
        dEnd = new Date(`2000-01-02T${end}:00`);
    }

    const diffMs = dEnd - dStart;
    const diffHrs = Math.floor(diffMs / 3600000);
    const diffMins = Math.floor((diffMs % 3600000) / 60000);

    document.getElementById('sleep-duration').textContent = `${diffHrs} giờ ${diffMins} phút`;
    document.getElementById('sleep-result').classList.remove('hidden');

    document.getElementById('home-sleep-val').textContent = `${diffHrs}h ${diffMins}m`;
}

// --- 4. Training ---
function saveSchedule() {
    const day = document.getElementById('schedule-day').value;
    const ex = document.getElementById('schedule-exercise').value;
    
    state.schedule[day] = ex;
    document.getElementById(`day-${day}`).innerHTML = `<strong>${day}:</strong> ${ex}`;
    
    // Extract kcal
    const match = ex.match(/-(\d+)\s*kcal/);
    if(match) {
        state.caloriesBurned += parseInt(match[1]);
    }
    updateUI();
}

// --- 5. Smart Nutrition ---
function initFoodSearch() {
    const searchInput = document.getElementById('food-search-input');
    const autocompleteList = document.getElementById('food-autocomplete-list');
    const weightInput = document.getElementById('food-weight');
    const previewVal = document.getElementById('preview-calories');

    // Mở/Đóng list
    searchInput.addEventListener('input', function() {
        const val = this.value.toLowerCase();
        autocompleteList.innerHTML = '';
        selectedFood = null; // Reset selection
        updatePreview();

        if (!val) {
            autocompleteList.classList.add('hidden');
            return;
        }

        let hasResult = false;
        foodDB.forEach(food => {
            if (food.name.toLowerCase().includes(val)) {
                hasResult = true;
                const li = document.createElement('li');
                li.className = 'autocomplete-item';
                li.innerHTML = `<span>${food.name}</span> <span class="cal-info">${food.cal} kcal/100g</span>`;
                li.onclick = () => {
                    searchInput.value = food.name;
                    selectedFood = food;
                    autocompleteList.classList.add('hidden');
                    updatePreview();
                };
                autocompleteList.appendChild(li);
            }
        });

        // Nếu không có kết quả, cho phép nhập Custom
        if (!hasResult) {
            const li = document.createElement('li');
            li.className = 'autocomplete-item';
            li.innerHTML = `<span><i class="fa-solid fa-plus"></i> Thêm tuỳ chỉnh: "${this.value}"</span>`;
            li.onclick = () => {
                const customCal = prompt(`Nhập số calo cho 100g (hoặc 1 phần) của "${this.value}":`);
                if(customCal && !isNaN(customCal)) {
                    selectedFood = { name: this.value, cal: parseInt(customCal) };
                    autocompleteList.classList.add('hidden');
                    updatePreview();
                }
            };
            autocompleteList.appendChild(li);
        }

        autocompleteList.classList.remove('hidden');
    });

    // Tính calo preview khi đổi khối lượng
    weightInput.addEventListener('input', updatePreview);

    // Ẩn list khi click ngoài
    document.addEventListener('click', (e) => {
        if (e.target !== searchInput) {
            autocompleteList.classList.add('hidden');
        }
    });
}

function updatePreview() {
    const weightInput = document.getElementById('food-weight');
    const previewVal = document.getElementById('preview-calories');
    if (selectedFood) {
        const weight = parseFloat(weightInput.value) || 0;
        const total = Math.round((selectedFood.cal * weight) / 100);
        // Nếu ng dùng nhập 1 (nghĩa là 1 phần), thì lấy nguyên cal
        const finalCal = (weight < 10) ? selectedFood.cal * weight : total; 
        previewVal.textContent = finalCal;
    } else {
        previewVal.textContent = "0";
    }
}

function addSmartCalories() {
    if (!selectedFood) return alert("Vui lòng chọn món ăn từ danh sách!");
    
    const weight = parseFloat(document.getElementById('food-weight').value) || 0;
    if (weight <= 0) return alert("Vui lòng nhập khối lượng lớn hơn 0!");

    const mealType = document.getElementById('meal-type').value;
    const finalCal = parseInt(document.getElementById('preview-calories').textContent);

    state.caloriesCurrent += finalCal;
    const now = new Date().toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'});
    
    const desc = `${selectedFood.name} (${weight}${weight < 10 ? ' phần' : 'g'})`;
    state.foodHistory.unshift({ time: now, meal: mealType, text: desc, cal: finalCal });

    document.getElementById('food-search-input').value = '';
    document.getElementById('preview-calories').textContent = '0';
    selectedFood = null;

    updateUI();
    alert("Đã lưu vào nhật ký!");
}


// --- Common UI Update ---
function updateUI() {
    // 1. Water
    document.getElementById('water-current').textContent = state.waterCurrent;
    document.getElementById('home-water-val').textContent = state.waterCurrent;
    
    let waterPct = (state.waterCurrent / state.waterTarget) * 100;
    if(waterPct > 100) waterPct = 100;
    document.getElementById('water-progress').style.width = `${waterPct}%`;
    document.getElementById('home-water-circle').setAttribute('stroke-dasharray', `${waterPct}, 100`);

    const wTimeline = document.getElementById('water-timeline');
    if(state.waterHistory.length > 0) {
        wTimeline.innerHTML = state.waterHistory.map(h => 
            `<div class="timeline-item"><div class="timeline-time">${h.time}</div><div>${h.text}</div></div>`
        ).join('');
    }

    // 2. Calories
    const netCalories = state.caloriesCurrent - state.caloriesBurned; // Tuỳ chọn có tính net hay ko
    
    document.getElementById('home-target-val').textContent = `/${state.bmr} kcal`;
    document.getElementById('target-calories').textContent = state.bmr;
    
    document.getElementById('home-calorie-val').textContent = state.caloriesCurrent;
    document.getElementById('total-calories').textContent = state.caloriesCurrent;
    document.getElementById('home-burn-val').textContent = state.caloriesBurned;

    let calPct = (state.caloriesCurrent / state.bmr) * 100;
    if(calPct > 100) calPct = 100;
    document.getElementById('calorie-progress').style.width = `${calPct}%`;
    document.getElementById('home-calorie-circle').setAttribute('stroke-dasharray', `${calPct}, 100`);

    const fTimeline = document.getElementById('food-timeline');
    if(state.foodHistory.length > 0) {
        fTimeline.innerHTML = state.foodHistory.map(h => 
            `<div class="timeline-item red">
                <div class="timeline-time">${h.time} - Bữa ${h.meal}</div>
                <div><strong>${h.text}</strong>: ${h.cal} kcal</div>
            </div>`
        ).join('');
    }
}
