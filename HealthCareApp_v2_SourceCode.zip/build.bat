@echo off
set "JAVA_HOME=C:\PROGRA~1\Android\ANDROI~1\jbr"
set "PATH=%JAVA_HOME%\bin;%PATH%"
cd /d C:\aaa\android
call gradlew.bat assembleDebug
